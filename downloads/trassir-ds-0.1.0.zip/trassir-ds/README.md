# TRASSIR DS — пакет для разработки, версия 0.1.0

Собрано из репозитория дизайн-системы командой `ds site build`. Руками не править: изменения идут через новый релиз контракта.

## Что внутри

| Путь | Что это |
|---|---|
| `contract/trassir-ds.contract.json` | Контракт: все токены, значения в светлой и тёмной теме, имена в Compose и SwiftUI, статусы. Формат — стандарт дизайн-токенов DTCG 2025.10 (W3C) |
| `contract/trassir-ds.contract.schema.json` | JSON Schema контракта |
| `contract/components/*.contract.json` | Контракты компонентов: свойства макета, состояния, токены по платформам, отличия от макета |
| `android/src/…` | `TrassirTokens.kt` для commonMain и `TrassirPlatformTokens` для androidMain и iosMain |
| `ios/Sources/TrassirTokens/TrassirTokens.swift` | Токены для SwiftUI |
| `CHANGELOG.md` | Что менялось от версии к версии |

## Android · Compose

Подключите папки как исходники модуля `:trassir-uikit`:

```kotlin
kotlin {
    sourceSets {
        commonMain { kotlin.srcDir("trassir-ds/android/src/commonMain/kotlin") }
        androidMain { kotlin.srcDir("trassir-ds/android/src/androidMain/kotlin") }
        iosMain { kotlin.srcDir("trassir-ds/android/src/iosMain/kotlin") }
    }
}
```

```kotlin
import ru.dssl.trassir.ds.tokens.TrassirTokens

Box(Modifier.padding(TrassirTokens.Spacing.l).background(TrassirTokens.Md.Sys.Dark.surface))
Text("Камера у входа", style = TrassirTokens.Md.Sys.Typescale.titleMedium)
```

В `TextStyle` нет семейства шрифта: Inter подключается из ресурсов приложения.

## iOS · SwiftUI

Скопируйте `TrassirTokens.swift` в `TrassirUIKit` или добавьте папку в пакет отдельной целью.

```swift
Text("Камера у входа")
    .font(TrassirTokens.Tr.Typography.ndBody1)
    .foregroundColor(TrassirTokens.Tr.Color.grayscale100)
    .padding(TrassirTokens.Tr.Spacing.standardPadding)
    .background(TrassirTokens.Tr.Color.grayscale800)
```

Имена повторяют текущий код: `TrColor.grayscale800` → `TrassirTokens.Tr.Color.grayscale800`.

## Совместимость версий

PATCH — поменялось значение. MINOR — добавлен ключ или ключ помечен deprecated с заменой. MAJOR — удалён ключ, который уже был deprecated. Смена типа запрещена. Пока версия 0.x, ломающее изменение выходит как MINOR.
