// Сгенерировано `ds tokens build` из tokens/*.tokens.json. Руками не править.
// Версия дизайн-системы: 0.1.0

package ru.dssl.trassir.ds.tokens

import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.text.TextStyle as ComposeTextStyle
import androidx.compose.ui.text.font.FontWeight as ComposeFontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object TrassirTokens {
    object Spacing {
        val xs: Dp = 4.dp
        val s: Dp = 8.dp
        val m: Dp = 12.dp
        val l: Dp = 16.dp
        val xl: Dp = 24.dp
        val xxl: Dp = 32.dp
    }
    object Md {
        object Sys {
            object Light {
                /** В коде: TrassirColors.md_theme_light_primary. Конфликт «primary», значение не сведено. */
                val primary: ComposeColor = ComposeColor(0xFF7168E8)
                /** В коде: TrassirColors.md_theme_light_onPrimary. */
                val onPrimary: ComposeColor = ComposeColor(0xFFF3EEFF)
                /** В коде: TrassirColors.md_theme_light_primaryContainer. */
                val primaryContainer: ComposeColor = ComposeColor(0xFFE3DFFF)
                /** В коде: TrassirColors.md_theme_light_onPrimaryContainer. */
                val onPrimaryContainer: ComposeColor = ComposeColor(0xFF130068)
                /** В коде: TrassirColors.md_theme_light_secondary. */
                val secondary: ComposeColor = ComposeColor(0xFF6750A4)
                /** В коде: TrassirColors.md_theme_light_onSecondary. */
                val onSecondary: ComposeColor = ComposeColor(0xFFFFFFFF)
                /** В коде: TrassirColors.md_theme_light_secondaryContainer. */
                val secondaryContainer: ComposeColor = ComposeColor(0xFFE9DDFF)
                /** В коде: TrassirColors.md_theme_light_onSecondaryContainer. */
                val onSecondaryContainer: ComposeColor = ComposeColor(0xFF22005D)
                /** В коде: TrassirColors.md_theme_light_tertiary. */
                val tertiary: ComposeColor = ComposeColor(0xFF604FAF)
                /** В коде: TrassirColors.md_theme_light_onTertiary. */
                val onTertiary: ComposeColor = ComposeColor(0xFFFFFFFF)
                /** В коде: TrassirColors.md_theme_light_tertiaryContainer. */
                val tertiaryContainer: ComposeColor = ComposeColor(0xFFE6DEFF)
                /** В коде: TrassirColors.md_theme_light_onTertiaryContainer. */
                val onTertiaryContainer: ComposeColor = ComposeColor(0xFF1C0062)
                /** В коде: TrassirColors.md_theme_light_error. Конфликт «error», значение не сведено. */
                val error: ComposeColor = ComposeColor(0xFFD63E3E)
                /** В коде: TrassirColors.md_theme_light_errorContainer. */
                val errorContainer: ComposeColor = ComposeColor(0xFFFFDAD6)
                /** В коде: TrassirColors.md_theme_light_onError. */
                val onError: ComposeColor = ComposeColor(0xFFFFFFFF)
                /** В коде: TrassirColors.md_theme_light_onErrorContainer. */
                val onErrorContainer: ComposeColor = ComposeColor(0xFF410002)
                /** В коде: TrassirColors.md_theme_light_background. */
                val background: ComposeColor = ComposeColor(0xFFFFFFFF)
                /** В коде: TrassirColors.md_theme_light_onBackground. */
                val onBackground: ComposeColor = ComposeColor(0xFF1C1B1F)
                /** В коде: TrassirColors.md_theme_light_surface. */
                val surface: ComposeColor = ComposeColor(0xFFF2F2F2)
                /** В коде: TrassirColors.md_theme_light_onSurface. */
                val onSurface: ComposeColor = ComposeColor(0xFF1C1B1F)
                /** В коде: TrassirColors.md_theme_light_surfaceVariant. */
                val surfaceVariant: ComposeColor = ComposeColor(0xFFF3EFFA)
                /** В коде: TrassirColors.md_theme_light_onSurfaceVariant. */
                val onSurfaceVariant: ComposeColor = ComposeColor(0xFF94929B)
                /** В коде: TrassirColors.md_theme_light_outline. */
                val outline: ComposeColor = ComposeColor(0xFF787680)
                /** В коде: TrassirColors.md_theme_light_inverseOnSurface. */
                val inverseOnSurface: ComposeColor = ComposeColor(0xFFF4EFF4)
                /** В коде: TrassirColors.md_theme_light_inverseSurface. */
                val inverseSurface: ComposeColor = ComposeColor(0xFF313034)
                /** В коде: TrassirColors.md_theme_light_inversePrimary. */
                val inversePrimary: ComposeColor = ComposeColor(0xFFC5C0FF)
                /** В коде: TrassirColors.md_theme_light_shadow. */
                val shadow: ComposeColor = ComposeColor(0xFF000000)
                /** В коде: TrassirColors.md_theme_light_surfaceTint. */
                val surfaceTint: ComposeColor = ComposeColor(0xFF554BCB)
                /** В коде: TrassirColors.md_theme_light_outlineVariant. */
                val outlineVariant: ComposeColor = ComposeColor(0xFFE0E0E0)
                /** В коде: TrassirColors.md_theme_light_scrim. */
                val scrim: ComposeColor = ComposeColor(0xFF000000)
            }
            object Dark {
                /** В коде: TrassirColors.md_theme_dark_primary. Конфликт «primary», значение не сведено. */
                val primary: ComposeColor = ComposeColor(0xFF7168E8)
                /** В коде: TrassirColors.md_theme_dark_onPrimary. */
                val onPrimary: ComposeColor = ComposeColor(0xFFF3EEFF)
                /** В коде: TrassirColors.md_theme_dark_primaryContainer. Конфликт «primaryContainerDark», значение не сведено. */
                val primaryContainer: ComposeColor get() = TrassirPlatformTokens.mdSysDarkPrimaryContainer
                /** В коде: TrassirColors.md_theme_dark_onPrimaryContainer. */
                val onPrimaryContainer: ComposeColor = ComposeColor(0xFFE3DFFF)
                /** В коде: TrassirColors.md_theme_dark_secondary. */
                val secondary: ComposeColor = ComposeColor(0xFF3E3E41)
                /** В коде: TrassirColors.md_theme_dark_onSecondary. */
                val onSecondary: ComposeColor = ComposeColor(0xFFFFFFFF)
                /** В коде: TrassirColors.md_theme_dark_secondaryContainer. */
                val secondaryContainer: ComposeColor = ComposeColor(0xFF4F378A)
                /** В коде: TrassirColors.md_theme_dark_onSecondaryContainer. */
                val onSecondaryContainer: ComposeColor = ComposeColor(0xFFE9DDFF)
                /** В коде: TrassirColors.md_theme_dark_tertiary. */
                val tertiary: ComposeColor = ComposeColor(0xFF604FAF)
                /** В коде: TrassirColors.md_theme_dark_onTertiary. */
                val onTertiary: ComposeColor = ComposeColor(0xFFFFFFFF)
                /** В коде: TrassirColors.md_theme_dark_tertiaryContainer. */
                val tertiaryContainer: ComposeColor = ComposeColor(0xFF483696)
                /** В коде: TrassirColors.md_theme_dark_onTertiaryContainer. */
                val onTertiaryContainer: ComposeColor = ComposeColor(0xFFE6DEFF)
                /** В коде: TrassirColors.md_theme_dark_error. Конфликт «error», значение не сведено. */
                val error: ComposeColor = ComposeColor(0xFFFFB4AB)
                /** В коде: TrassirColors.md_theme_dark_errorContainer. */
                val errorContainer: ComposeColor = ComposeColor(0xFF93000A)
                /** В коде: TrassirColors.md_theme_dark_onError. */
                val onError: ComposeColor = ComposeColor(0xFF690005)
                /** В коде: TrassirColors.md_theme_dark_onErrorContainer. */
                val onErrorContainer: ComposeColor = ComposeColor(0xFFFFDAD6)
                /** В коде: TrassirColors.md_theme_dark_background. */
                val background: ComposeColor = ComposeColor(0xFF151515)
                /** В коде: TrassirColors.md_theme_dark_onBackground. */
                val onBackground: ComposeColor = ComposeColor(0xFFFFFBFF)
                /** В коде: TrassirColors.md_theme_dark_surface. Конфликт «surfaceContainer», значение не сведено. */
                val surface: ComposeColor = ComposeColor(0xFF252527)
                /** В коде: TrassirColors.md_theme_dark_onSurface. */
                val onSurface: ComposeColor = ComposeColor(0xFFFFFFFF)
                /** В коде: TrassirColors.md_theme_dark_surfaceVariant. */
                val surfaceVariant: ComposeColor = ComposeColor(0xFF1D1D1D)
                /** В коде: TrassirColors.md_theme_dark_onSurfaceVariant. */
                val onSurfaceVariant: ComposeColor = ComposeColor(0xFFC8C5D0)
                /** В коде: TrassirColors.md_theme_dark_outline. Конфликт «outline», значение не сведено. */
                val outline: ComposeColor = ComposeColor(0xFF928F99)
                /** В коде: TrassirColors.md_theme_dark_inverseOnSurface. */
                val inverseOnSurface: ComposeColor = ComposeColor(0xFF1C1B1F)
                /** В коде: TrassirColors.md_theme_dark_inverseSurface. */
                val inverseSurface: ComposeColor = ComposeColor(0xFFE5E1E6)
                /** В коде: TrassirColors.md_theme_dark_inversePrimary. */
                val inversePrimary: ComposeColor = ComposeColor(0xFF554BCB)
                /** В коде: TrassirColors.md_theme_dark_shadow. */
                val shadow: ComposeColor = ComposeColor(0xFF000000)
                /** В коде: TrassirColors.md_theme_dark_surfaceTint. */
                val surfaceTint: ComposeColor = ComposeColor(0xFFC5C0FF)
                /** В коде: TrassirColors.md_theme_dark_outlineVariant. */
                val outlineVariant: ComposeColor = ComposeColor(0xFF242424)
                /** В коде: TrassirColors.md_theme_dark_scrim. */
                val scrim: ComposeColor = ComposeColor(0xFF000000)
            }
            object Shape {
                /** В коде: Shapes.small. */
                val small: Dp = 4.dp
                /** В коде: Shapes.medium. */
                val medium: Dp = 8.dp
                /** В коде: Shapes.large. */
                val large: Dp = 12.dp
                /** В коде: Shapes.extraLarge. */
                val extraLarge: Dp = 28.dp
            }
            object Typescale {
                /** В коде: Typography.displayLarge. */
                /** Шрифт: Inter. */
                val displayLarge: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(400), fontSize = 57.sp, lineHeight = 64.sp, letterSpacing = (-0.25).sp)
                /** В коде: Typography.displayMedium. */
                /** Шрифт: Inter. */
                val displayMedium: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(400), fontSize = 45.sp, lineHeight = 52.sp, letterSpacing = 0.sp)
                /** В коде: Typography.displaySmall. */
                /** Шрифт: Inter. */
                val displaySmall: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(400), fontSize = 36.sp, lineHeight = 44.sp, letterSpacing = 0.sp)
                /** В коде: Typography.headlineLarge. */
                /** Шрифт: Inter. */
                val headlineLarge: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(400), fontSize = 32.sp, lineHeight = 40.sp, letterSpacing = 0.sp)
                /** В коде: Typography.headlineMedium. */
                /** Шрифт: Inter. */
                val headlineMedium: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(400), fontSize = 28.sp, lineHeight = 36.sp, letterSpacing = 0.sp)
                /** В коде: Typography.headlineSmall. */
                /** Шрифт: Inter. */
                val headlineSmall: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(400), fontSize = 24.sp, lineHeight = 32.sp, letterSpacing = 0.sp)
                /** В коде: Typography.titleLarge. */
                /** Шрифт: Inter. */
                val titleLarge: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(400), fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = 0.sp)
                /** В коде: Typography.titleMedium. */
                /** Шрифт: Inter. */
                val titleMedium: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(500), fontSize = 16.sp, lineHeight = 24.sp, letterSpacing = 0.1.sp)
                /** В коде: Typography.titleSmall. */
                /** Шрифт: Inter. */
                val titleSmall: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(500), fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp)
                /** В коде: Typography.bodyLarge. */
                /** Шрифт: Inter. */
                val bodyLarge: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(400), fontSize = 16.sp, lineHeight = 24.sp, letterSpacing = 0.5.sp)
                /** В коде: Typography.bodyMedium. */
                /** Шрифт: Inter. */
                val bodyMedium: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(400), fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.25.sp)
                /** В коде: Typography.bodySmall. */
                /** Шрифт: Inter. */
                val bodySmall: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(400), fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.4.sp)
                /** В коде: Typography.labelLarge. */
                /** Шрифт: Inter. */
                val labelLarge: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(500), fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.1.sp)
                /** В коде: Typography.labelMedium. */
                /** Шрифт: Inter. */
                val labelMedium: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(500), fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.5.sp)
                /** В коде: Typography.labelSmall. */
                /** Шрифт: Inter. */
                val labelSmall: ComposeTextStyle = ComposeTextStyle(fontWeight = ComposeFontWeight(500), fontSize = 11.sp, lineHeight = 16.sp, letterSpacing = 0.5.sp)
            }
        }
    }
    object Custom {
        object Color {
            /** В коде: TrassirColors.OkColor. */
            val OkColor: ComposeColor = ComposeColor(0xFF33CC00)
            /** В коде: TrassirColors.Color_Zoom. */
            val Color_Zoom: ComposeColor = ComposeColor(0xFF3060A7)
            /** В коде: TrassirColors.Color_Iris. */
            val Color_Iris: ComposeColor = ComposeColor(0xFF3A7B41)
            /** В коде: TrassirColors.Color_Focus. */
            val Color_Focus: ComposeColor = ComposeColor(0xFF8A3C3C)
            /** В коде: TrassirColors.timelineBackgroundColorLight. */
            val timelineBackgroundColorLight: ComposeColor = ComposeColor(0xFFCCCCCC)
            /** В коде: TrassirColors.timelineBackgroundColorDark. */
            val timelineBackgroundColorDark: ComposeColor = ComposeColor(0xFF3E3E41)
            /** В коде: TrassirColors.timelinePermanentRecordColor. */
            val timelinePermanentRecordColor: ComposeColor = ComposeColor(0xFF7367F0)
            /** В коде: TrassirColors.timelineMotionRecordColor. */
            val timelineMotionRecordColor: ComposeColor = ComposeColor(0xFF7367F0)
            /** В коде: TrassirColors.timelineSoundRecordColor. */
            val timelineSoundRecordColor: ComposeColor = ComposeColor(0xFFF7F6B0)
            /** В коде: TrassirColors.timelineLoadingColor. */
            val timelineLoadingColor: ComposeColor = ComposeColor(0xFFCBFBFF)
            /** В коде: TrassirColors.onTimelinePermanentRecordColor. */
            val onTimelinePermanentRecordColor: ComposeColor = ComposeColor(0xFFF59616)
            /** В коде: TrassirColors.onTimelineMotionRecordColor. */
            val onTimelineMotionRecordColor: ComposeColor = ComposeColor(0xFFFFFFFF)
            /** В коде: TrassirColors.onTimelineSoundRecordColor. */
            val onTimelineSoundRecordColor: ComposeColor = ComposeColor(0xFF5008A8)
            /** В коде: TrassirColors.onTimelineLoadingColor. */
            val onTimelineLoadingColor: ComposeColor = ComposeColor(0xFF232B2C)
            /** В коде: TrassirColors.onTimelineErrorColor. */
            val onTimelineErrorColor: ComposeColor = ComposeColor(0xFF000000)
            /** В коде: TrassirColors.controlWithExport. */
            val controlWithExport: ComposeColor = ComposeColor(0xFFFDD835)
            /** В коде: TrassirColors.disableActionColor. */
            val disableActionColor: ComposeColor = ComposeColor(0xFFF0AFB4)
            /** В коде: TrassirColors.onDisableActionColor. */
            val onDisableActionColor: ComposeColor = ComposeColor(0xFF68131B)
            /** В коде: TrassirColors.accelerateActionColor. */
            val accelerateActionColor: ComposeColor = ComposeColor(0xFF5C54C5)
            /** В коде: TrassirColors.slowDownActionColor. */
            val slowDownActionColor: ComposeColor = ComposeColor(0xFF525067)
            /** В коде: TrassirColors.timelineErrorColor. */
            val timelineErrorColor: ComposeColor = ComposeColor(0xFFD63E3E)
        }
    }
}

/** Значения, которые в коде приложения различаются между androidMain и iosMain. */
expect object TrassirPlatformTokens {
    val mdSysDarkPrimaryContainer: ComposeColor
}
