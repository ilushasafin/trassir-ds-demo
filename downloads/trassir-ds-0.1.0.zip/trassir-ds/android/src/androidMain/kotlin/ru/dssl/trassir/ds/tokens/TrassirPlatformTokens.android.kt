// Сгенерировано `ds tokens build` из tokens/*.tokens.json. Руками не править.
// Версия дизайн-системы: 0.1.0

package ru.dssl.trassir.ds.tokens

import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.text.TextStyle as ComposeTextStyle
import androidx.compose.ui.text.font.FontWeight as ComposeFontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

actual object TrassirPlatformTokens {
    actual val mdSysDarkPrimaryContainer: ComposeColor = ComposeColor(0xFF3D2FB2)
}
