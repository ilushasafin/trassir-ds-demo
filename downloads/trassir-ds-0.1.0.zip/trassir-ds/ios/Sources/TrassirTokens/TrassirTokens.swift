// Сгенерировано `ds tokens build` из tokens/*.tokens.json. Руками не править.
// Версия дизайн-системы: 0.1.0

import SwiftUI

public enum TrassirTokens {
    public enum Spacing {
        public static let xs: CGFloat = 4
        public static let s: CGFloat = 8
        public static let m: CGFloat = 12
        public static let l: CGFloat = 16
        public static let xl: CGFloat = 24
        public static let xxl: CGFloat = 32
    }
    public enum Tr {
        public enum Color {
            /// В коде: TrColor.grayscale100.
            public static let grayscale100: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 255.0 / 255.0, green: 255.0 / 255.0, blue: 255.0 / 255.0, opacity: 1)
            /// В коде: TrColor.grayscale200.
            public static let grayscale200: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 242.0 / 255.0, green: 242.0 / 255.0, blue: 242.0 / 255.0, opacity: 1)
            /// В коде: TrColor.grayscale300.
            public static let grayscale300: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 224.0 / 255.0, green: 224.0 / 255.0, blue: 224.0 / 255.0, opacity: 1)
            /// В коде: TrColor.grayscale400.
            public static let grayscale400: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 218.0 / 255.0, green: 218.0 / 255.0, blue: 218.0 / 255.0, opacity: 1)
            /// В коде: TrColor.grayscale500.
            public static let grayscale500: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 199.0 / 255.0, green: 199.0 / 255.0, blue: 199.0 / 255.0, opacity: 1)
            /// В коде: TrColor.grayscale600. Конфликт «outline», значение не сведено.
            public static let grayscale600: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 150.0 / 255.0, green: 150.0 / 255.0, blue: 150.0 / 255.0, opacity: 1)
            /// В коде: TrColor.grayscale700.
            public static let grayscale700: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 61.0 / 255.0, green: 61.0 / 255.0, blue: 61.0 / 255.0, opacity: 1)
            /// В коде: TrColor.grayscale800. Конфликт «surfaceContainer», значение не сведено.
            public static let grayscale800: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 36.0 / 255.0, green: 36.0 / 255.0, blue: 36.0 / 255.0, opacity: 1)
            /// В коде: TrColor.grayscale900.
            public static let grayscale900: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 21.0 / 255.0, green: 21.0 / 255.0, blue: 21.0 / 255.0, opacity: 1)
            /// В коде: TrColor.micOverlay.
            public static let micOverlay: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 25.0 / 255.0, green: 25.0 / 255.0, blue: 26.0 / 255.0, opacity: 1)
            /// В коде: TrColor.primary. Конфликт «primary», значение не сведено.
            public static let primary: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 115.0 / 255.0, green: 103.0 / 255.0, blue: 240.0 / 255.0, opacity: 1)
            /// В коде: TrColor.primaryDark.
            public static let primaryDark: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 65.0 / 255.0, green: 72.0 / 255.0, blue: 127.0 / 255.0, opacity: 1)
            /// В коде: TrColor.primaryLight.
            public static let primaryLight: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 178.0 / 255.0, green: 159.0 / 255.0, blue: 252.0 / 255.0, opacity: 1)
            /// В коде: TrColor.additionalSuccessful.
            public static let additionalSuccessful: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 51.0 / 255.0, green: 204.0 / 255.0, blue: 0.0 / 255.0, opacity: 1)
            /// В коде: TrColor.additionalError. Конфликт «error», значение не сведено.
            public static let additionalError: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 234.0 / 255.0, green: 15.0 / 255.0, blue: 15.0 / 255.0, opacity: 1)
            /// В коде: TrColor.additionalVideoCrop.
            public static let additionalVideoCrop: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 251.0 / 255.0, green: 189.0 / 255.0, blue: 0.0 / 255.0, opacity: 1)
            /// В коде: TrColor.ndError.
            public static let ndError: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 240.0 / 255.0, green: 175.0 / 255.0, blue: 180.0 / 255.0, opacity: 1)
            /// В коде: TrColor.ndOnError.
            public static let ndOnError: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 104.0 / 255.0, green: 19.0 / 255.0, blue: 27.0 / 255.0, opacity: 1)
            /// В коде: TrColor.ndPrimary.
            public static let ndPrimary: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 167.0 / 255.0, green: 162.0 / 255.0, blue: 216.0 / 255.0, opacity: 1)
            /// В коде: TrColor.eventMotion.
            public static let eventMotion: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 115.0 / 255.0, green: 103.0 / 255.0, blue: 240.0 / 255.0, opacity: 1)
            /// В коде: TrColor.eventSound.
            public static let eventSound: SwiftUI.Color = SwiftUI.Color(.sRGB, red: 115.0 / 255.0, green: 103.0 / 255.0, blue: 240.0 / 255.0, opacity: 1)
        }
        public enum Typography {
            /// В коде: TrTypography.Style.title1. TODO: в коде нет letterSpacing, lineHeight.
            public static let title1: SwiftUI.Font = SwiftUI.Font.system(size: 26, weight: .semibold)
            /// В коде: TrTypography.Style.title2. TODO: в коде нет letterSpacing, lineHeight.
            public static let title2: SwiftUI.Font = SwiftUI.Font.system(size: 26, weight: .medium)
            /// В коде: TrTypography.Style.title3. TODO: в коде нет letterSpacing, lineHeight.
            public static let title3: SwiftUI.Font = SwiftUI.Font.system(size: 22, weight: .semibold)
            /// В коде: TrTypography.Style.title4. TODO: в коде нет letterSpacing, lineHeight.
            public static let title4: SwiftUI.Font = SwiftUI.Font.system(size: 20, weight: .semibold)
            /// В коде: TrTypography.Style.title5. TODO: в коде нет letterSpacing, lineHeight.
            public static let title5: SwiftUI.Font = SwiftUI.Font.system(size: 20, weight: .regular)
            /// В коде: TrTypography.Style.headline1. TODO: в коде нет letterSpacing, lineHeight.
            public static let headline1: SwiftUI.Font = SwiftUI.Font.system(size: 18, weight: .semibold)
            /// В коде: TrTypography.Style.headline2. TODO: в коде нет letterSpacing, lineHeight.
            public static let headline2: SwiftUI.Font = SwiftUI.Font.system(size: 18, weight: .medium)
            /// В коде: TrTypography.Style.headline3. TODO: в коде нет letterSpacing, lineHeight.
            public static let headline3: SwiftUI.Font = SwiftUI.Font.system(size: 18, weight: .regular)
            /// В коде: TrTypography.Style.body1. TODO: в коде нет letterSpacing, lineHeight.
            public static let body1: SwiftUI.Font = SwiftUI.Font.system(size: 16, weight: .semibold)
            /// В коде: TrTypography.Style.body2. TODO: в коде нет letterSpacing, lineHeight.
            public static let body2: SwiftUI.Font = SwiftUI.Font.system(size: 16, weight: .medium)
            /// В коде: TrTypography.Style.body3. TODO: в коде нет letterSpacing, lineHeight.
            public static let body3: SwiftUI.Font = SwiftUI.Font.system(size: 16, weight: .regular)
            /// В коде: TrTypography.Style.body4. TODO: в коде нет letterSpacing, lineHeight.
            public static let body4: SwiftUI.Font = SwiftUI.Font.system(size: 14, weight: .semibold)
            /// В коде: TrTypography.Style.body5. TODO: в коде нет letterSpacing, lineHeight.
            public static let body5: SwiftUI.Font = SwiftUI.Font.system(size: 14, weight: .medium)
            /// В коде: TrTypography.Style.body6. TODO: в коде нет letterSpacing, lineHeight.
            public static let body6: SwiftUI.Font = SwiftUI.Font.system(size: 14, weight: .regular)
            /// В коде: TrTypography.Style.caption1. TODO: в коде нет letterSpacing, lineHeight.
            public static let caption1: SwiftUI.Font = SwiftUI.Font.system(size: 12, weight: .medium)
            /// В коде: TrTypography.Style.caption2. TODO: в коде нет letterSpacing, lineHeight.
            public static let caption2: SwiftUI.Font = SwiftUI.Font.system(size: 12, weight: .regular)
            /// В коде: TrTypography.Style.caption3. TODO: в коде нет letterSpacing, lineHeight.
            public static let caption3: SwiftUI.Font = SwiftUI.Font.system(size: 10, weight: .regular)
            /// В коде: TrTypography.Style.ndNavTitle. TODO: в коде нет letterSpacing, lineHeight.
            public static let ndNavTitle: SwiftUI.Font = SwiftUI.Font.system(size: 17, weight: .semibold)
            /// В коде: TrTypography.Style.ndButton. TODO: в коде нет letterSpacing, lineHeight.
            public static let ndButton: SwiftUI.Font = SwiftUI.Font.system(size: 14, weight: .medium)
            /// В коде: TrTypography.Style.ndTitle1. TODO: в коде нет letterSpacing, lineHeight.
            public static let ndTitle1: SwiftUI.Font = SwiftUI.Font.system(size: 22, weight: .regular)
            /// В коде: TrTypography.Style.ndTitle2. TODO: в коде нет letterSpacing, lineHeight.
            public static let ndTitle2: SwiftUI.Font = SwiftUI.Font.system(size: 12, weight: .medium)
            /// В коде: TrTypography.Style.ndBody1. TODO: в коде нет letterSpacing, lineHeight.
            public static let ndBody1: SwiftUI.Font = SwiftUI.Font.system(size: 16, weight: .regular)
            /// В коде: TrTypography.Style.ndBody2. TODO: в коде нет letterSpacing, lineHeight.
            public static let ndBody2: SwiftUI.Font = SwiftUI.Font.system(size: 14, weight: .regular)
            /// В коде: TrTypography.Style.ndBody3. TODO: в коде нет letterSpacing, lineHeight.
            public static let ndBody3: SwiftUI.Font = SwiftUI.Font.system(size: 12, weight: .regular)
            /// В коде: TrTypography.Style.ndCaption1. TODO: в коде нет letterSpacing, lineHeight.
            public static let ndCaption1: SwiftUI.Font = SwiftUI.Font.system(size: 11, weight: .semibold)
        }
        public enum Radius {
            /// В коде: ModuleConstants.Visual.cornerRadiusStandard.
            public static let cornerRadiusStandard: CGFloat = 12
            /// В коде: ModuleConstants.Visual.cornerRadiusSmall.
            public static let cornerRadiusSmall: CGFloat = 8
            /// В коде: ModuleConstants.Visual.cornerRadiusNewDesign.
            public static let cornerRadiusNewDesign: CGFloat = 10
        }
        public enum Spacing {
            /// В коде: ModuleConstants.Visual.labelToFieldPadding.
            public static let labelToFieldPadding: CGFloat = 4
            /// В коде: ModuleConstants.Visual.smallPadding.
            public static let smallPadding: CGFloat = 8
            /// В коде: ModuleConstants.Visual.mediumPadding.
            public static let mediumPadding: CGFloat = 12
            /// В коде: ModuleConstants.Visual.standardPadding.
            public static let standardPadding: CGFloat = 16
            /// В коде: ModuleConstants.Visual.largePadding.
            public static let largePadding: CGFloat = 24
            /// В коде: ModuleConstants.Visual.extraLargePadding.
            public static let extraLargePadding: CGFloat = 32
        }
        public enum Size {
            /// В коде: ModuleConstants.Visual.blur.
            public static let blur: CGFloat = 10
            /// В коде: ModuleConstants.Visual.buttonHeightNewDesign.
            public static let buttonHeightNewDesign: CGFloat = 44
            /// В коде: ModuleConstants.Visual.standardIconSize.
            public static let standardIconSize: CGFloat = 24
            /// В коде: ModuleConstants.Visual.SheetHeight.alertSheetHeight.
            public static let alertSheetHeight: CGFloat = 192
            /// В коде: ModuleConstants.Visual.SheetHeight.deletePresetSheetHeight.
            public static let deletePresetSheetHeight: CGFloat = 212
            /// В коде: ModuleConstants.Visual.SheetHeight.errorSheetHeight.
            public static let errorSheetHeight: CGFloat = 300
            /// В коде: ModuleConstants.Visual.SheetHeight.loginInvalidCredentialsSheetHeight.
            public static let loginInvalidCredentialsSheetHeight: CGFloat = 220
            /// В коде: ModuleConstants.Visual.SheetHeight.errorOpenedSheetHeight.
            public static let errorOpenedSheetHeight: CGFloat = 400
            /// В коде: ModuleConstants.Visual.SheetHeight.qrHintHeight.
            public static let qrHintHeight: CGFloat = 520
            /// В коде: ModuleConstants.Visual.listItemHeight.
            public static let listItemHeight: CGFloat = 40
            public enum AlertPopUpSize {
                /// В коде: ModuleConstants.Visual.PopUpSize.alertPopUpSize.width.
                public static let width: CGFloat = 320
                /// В коде: ModuleConstants.Visual.PopUpSize.alertPopUpSize.height.
                public static let height: CGFloat = 200
            }
            public enum UnavailablePopUpSize {
                /// В коде: ModuleConstants.Visual.PopUpSize.unavailablePopUpSize.width.
                public static let width: CGFloat = 340
                /// В коде: ModuleConstants.Visual.PopUpSize.unavailablePopUpSize.height.
                public static let height: CGFloat = 160
            }
        }
    }
}
